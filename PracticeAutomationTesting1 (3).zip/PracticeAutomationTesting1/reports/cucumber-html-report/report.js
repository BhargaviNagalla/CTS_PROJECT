$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/feature/testcase.feature");
formatter.feature({
  "line": 2,
  "name": "Practice_Automation_Testing website",
  "description": "",
  "id": "practice-automation-testing-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Practice.AutomationTesting.in"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Validate the login fuctionality",
  "description": "",
  "id": "practice-automation-testing-website;validate-the-login-fuctionality",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@TS_01_login"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Launch the browser and enter the url",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Login page is opened",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Enter the \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Click the login button",
  "keyword": "And "
});
formatter.match({
  "location": "automation_login_pagestep.launch_the_browser_and_enter_the_url()"
});
formatter.result({
  "duration": 62063587000,
  "status": "passed"
});
formatter.match({
  "location": "automation_login_pagestep.login_page_is_opened()"
});
formatter.result({
  "duration": 256168000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u003cusername\u003e",
      "offset": 11
    },
    {
      "val": "\u003cpassword\u003e",
      "offset": 28
    }
  ],
  "location": "automation_login_pagestep.enter_the_and(String,String)"
});
formatter.result({
  "duration": 16946351600,
  "status": "passed"
});
formatter.match({
  "location": "automation_login_pagestep.click_the_login_button()"
});
formatter.result({
  "duration": 31535134900,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "edit and save Billing Address",
  "description": "",
  "id": "practice-automation-testing-website;edit-and-save-billing-address",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 11,
      "name": "@TS_02_Edit_and_save_Billing_Address"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "open url in a browser07",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "login into application with\"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "click on the addresses",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "click edit billing address",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "fill the billing details",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "click save Addresses",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "Assert Billing addresses changes successfully",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "07",
      "offset": 21
    }
  ],
  "location": "BillingAddressstepdefination.open_url_in_a_browser(int)"
});
formatter.result({
  "duration": 32706672600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u003cusername\u003e",
      "offset": 28
    },
    {
      "val": "\u003cpassword\u003e",
      "offset": 45
    }
  ],
  "location": "BillingAddressstepdefination.login_into_application_with_and(String,String)"
});
formatter.result({
  "duration": 28244055600,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefination.click_on_the_addresses()"
});
formatter.result({
  "duration": 1824691600,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefination.click_edit_billing_address()"
});
formatter.result({
  "duration": 4499123900,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefination.fill_the_billing_details()"
});
formatter.result({
  "duration": 7700061600,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefination.click_save_Addresses()"
});
formatter.result({
  "duration": 12175190400,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefination.assert_Billing_addresses_changes_successfully()"
});
formatter.result({
  "duration": 7152903200,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "edit and save shipping addresses details",
  "description": "",
  "id": "practice-automation-testing-website;edit-and-save-shipping-addresses-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 21,
      "name": "@TS_03_Edit_and_Save_Shipping_Address"
    }
  ]
});
formatter.step({
  "line": 23,
  "name": "open url in a browser_08",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "login with \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "click on the addresses tab",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "click on edit shipping addresses",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "fill the shipping details",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "click on save addresses button",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "Assert shipping addresses changed successfully",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "08",
      "offset": 22
    }
  ],
  "location": "ShippingAddressstepdefination.open_url_in_a_browser_(int)"
});
formatter.result({
  "duration": 24608204100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u003cusername\u003e",
      "offset": 12
    },
    {
      "val": "\u003cpassword\u003e",
      "offset": 29
    }
  ],
  "location": "ShippingAddressstepdefination.login_with_and(String,String)"
});
formatter.result({
  "duration": 9317473900,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefination.click_on_the_addresses_tab()"
});
formatter.result({
  "duration": 2380562700,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefination.click_on_edit_shipping_addresses()"
});
formatter.result({
  "duration": 5908513900,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefination.fill_the_shipping_details()"
});
formatter.result({
  "duration": 9465578600,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefination.click_on_save_addresses_button()"
});
formatter.result({
  "duration": 5230286600,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefination.assert_shipping_addresses_changed_successfully()"
});
formatter.result({
  "duration": 15268399300,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "Demosite - register",
  "description": "",
  "id": "practice-automation-testing-website;demosite---register",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 31,
      "name": "@TS_04_Demosite_Valid_Register"
    }
  ]
});
formatter.step({
  "line": 33,
  "name": "open the url in the browser06",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "click demosite- register menu",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "fill all the valid details",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "click submit button",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "06",
      "offset": 27
    }
  ],
  "location": "DemoValidRegstepdefination.open_the_url_in_the_browser(int)"
});
formatter.result({
  "duration": 29109070600,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefination.click_demosite_register_menu()"
});
formatter.result({
  "duration": 5374839000,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefination.fill_all_the_valid_details()"
});
formatter.result({
  "duration": 13347664500,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefination.click_submit_button()"
});
formatter.result({
  "duration": 178582600,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "Update details and chane password",
  "description": "",
  "id": "practice-automation-testing-website;update-details-and-chane-password",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 40,
      "name": "@TS_05_update_Account_Details"
    }
  ]
});
formatter.step({
  "line": 42,
  "name": "open the url in the browser_09",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "login with the \"\u003cUsername\u003e\" and \"\u003cPassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "click on the account details",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "upadte details with new password",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "click save changes button",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "09",
      "offset": 28
    }
  ],
  "location": "UpdatePasswordstepdefination.open_the_url_in_the_browser_(int)"
});
formatter.result({
  "duration": 42628129500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "\u003cUsername\u003e",
      "offset": 16
    },
    {
      "val": "\u003cPassword\u003e",
      "offset": 33
    }
  ],
  "location": "UpdatePasswordstepdefination.login_with_the_and(String,String)"
});
formatter.result({
  "duration": 17113328800,
  "status": "passed"
});
formatter.match({
  "location": "UpdatePasswordstepdefination.click_on_the_account_details()"
});
formatter.result({
  "duration": 7589592600,
  "status": "passed"
});
formatter.match({
  "location": "UpdatePasswordstepdefination.upadte_details_with_new_password()"
});
formatter.result({
  "duration": 11677801600,
  "status": "passed"
});
formatter.match({
  "location": "UpdatePasswordstepdefination.click_save_changes_button()"
});
formatter.result({
  "duration": 2129411700,
  "status": "passed"
});
});