package com.pages;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class DemoValidRegPage {
	WebDriver driver;
	By FirstName=By.xpath("//input[@placeholder='First Name']");
	By LastName=By.xpath("//input[@placeholder='Last Name']");
	By address=By.xpath("//textarea[@ng-model='Adress']");
	By Email=By.xpath("//input[@ng-model='EmailAdress']");
	By Gender=By.xpath("//input[@value='FeMale']");
	By phone=By.xpath("//input[@ng-model='Phone']");
	By checkbox1=By.id("checkbox1");
	By checkbox3=By.id("checkbox3");
	By language=By.xpath("//div[@style='min-height:30px;max-width:200px']");
	By English=By.linkText("English");
	By Skills=By.id("Skills");
	By text=By.xpath("//select[@type='text']");
	By country=By.xpath("//option[@value='India']");
	By select=By.xpath("//span[@class='select2-selection select2-selection--single']");
	By searchtext=By.xpath("//input[@type='search']");
	By countrytext=By.xpath("//input[@type='search']");
	By year=By.id("yearbox");
	By Month=By.xpath("//select[@placeholder='Month']");
	By day=By.id("daybox");
	By Firstpassword=By.id("firstpassword");
	By secondpassword=By.id("secondpassword");
	By uploadingElement=By.xpath("//input[@type='file']");
	//By ClickSubmit=By.xpath("//button[@value='sign up']");
	By ClickSubmit=By.xpath("//*[@id=\"submitbtn\"]");
	By validreg=By.xpath("/html/body/section/div[1]/div/div[2]/h4[1]/b");
	By Demosite=By.linkText("Demo Site");
	public DemoValidRegPage(WebDriver driver) 
	{
		this.driver =driver;
	}
	
		//To click on demosite
	public void ClickDemosite() {
		driver.findElement(Demosite).click();
	
	}
	//To fill valid details
	public void fillValiddetails() throws Exception {
		driver.findElement(FirstName).sendKeys("Bhargavi");
		driver.findElement(LastName).sendKeys("Nagalla");
		driver.findElement(address).sendKeys("vadlamudi,guntur");
		driver.findElement(Email).sendKeys("bhargavinagalla15@gmail.com");
		List<WebElement> rb = driver.findElements(Gender);
		((WebElement) rb.get(0)).click();
		driver.findElement(phone).sendKeys("9010708135");
		driver.findElement(checkbox1).click();
		driver.findElement(checkbox3).click();
		 // driver.findElement(By.xpath("//div[@style='min-height:30px;max-width:200px']")).click(); 
		// driver.findElement(By.linkText("English")).click();
		//driver.findElement(language).click();
		//driver.findElement(English).click();
		WebElement we1 = driver.findElement(Skills);
		Select se1= new Select(we1);
		se1.selectByVisibleText("C");
		driver.findElement(text).click();
		driver.findElement(country).click();
		
		 driver.findElement(By.xpath("/html/body/section/div/div/div[2]/form/div[10]/div/span/span[1]/span")).click();
		 driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("India");
		 
		 driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys(Keys.ENTER);
		 
		 
		  driver.findElement(select).click();
		  driver.findElement(searchtext).click();
		  driver.findElement(countrytext).sendKeys("India");
		  Actions act = new Actions(driver); 
		  Thread.sleep(30);
		  act.sendKeys(Keys.ENTER);
		WebElement we6 = driver.findElement(year);
		Select se6= new Select(we6);
		se6.selectByVisibleText("1994");
		
		WebElement we4 = driver.findElement(Month);
		Select se4 = new Select(we4);
		se4.selectByVisibleText("September");
		WebElement we5 = driver.findElement(day);
		Select se5 = new Select(we5);
		se5.selectByVisibleText("30");
		driver.findElement(Firstpassword).sendKeys("Chinni@12");
		driver.findElement(secondpassword).sendKeys("Chinni@12");
		WebElement uploadElement = driver.findElement(uploadingElement);
		uploadElement.sendKeys("C:\\Users\\User\\Pictures\\Screenshots\\Screenshot (1).png");

	}
	//To click on submit
	public void clickSubmit() {
		driver.findElement(ClickSubmit).click();
	}
	//Assert
	public void AssertValidreg() {
		String b = driver.findElement(validreg).getText();
		//Assert.assertEquals(" - Double Click on Edit Icon to ",b);
		System.out.println(b);
		System.out.println("submitted Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("src\\test\\resources\\screenShot\\DemovalidReg.png"));
	}
	//To close the browser window
		public void quit() {
			driver.close();
		}
	
}


